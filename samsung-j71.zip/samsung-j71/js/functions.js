(function($){
	$(document).ready(function (){
		$('.of-iconmntop').click(function(){
			$('.of-menutop').toggleClass('of-mnshow');
		});

		$('.of-search').click(function(){
			$('.of-searchbox').show(200);
		});

		$('.of-closesearch').click(function(){
			$('.of-searchbox').hide(200);
		});
	});

 var galleryThumbs = new Swiper('.gallery-thumbs', {
      spaceBetween: 5,
      slidesPerView: 2,
      freeMode: true,
      watchSlidesVisibility: true,
      watchSlidesProgress: true,
    });
    var galleryTop = new Swiper('.gallery-top', {
      spaceBetween: 1,
      navigation: {},
      thumbs: {
        swiper: galleryThumbs
      }
    });
    $('.f1-li1').click(function () {
      $('.f1-tmlul li').removeClass('active');
      $(this).addClass('active');
    });
    $('.f1-li2').click(function () {
      $('.f1-li2').removeClass('active');
      $('.f1-li3').removeClass('active');
      $('.f1-li1').addClass('active');
      $(this).addClass('active');
    });
    $('.f1-li3').click(function () {
      $('.f1-li1').addClass('active');
      $('.f1-li2').addClass('active');
      $(this).addClass('active');
    });
    $(window).on("load",function(){
      $(".content").mCustomScrollbar();
    });

    $("input.tick-tick").change(function () {
			if ($("input.tick-tick:checked").val() == "ssYel") {
				$('.ss-dh-img img').attr('src', 'images/298/gold.png');
			}
			else if ($("input.tick-tick:checked").val() == "ssSil") {
				$('.ss-dh-img img').attr('src', 'images/298/bac.png');
			}
			else if ($("input.tick-tick:checked").val() == "ssBla") {
				$('.ss-dh-img img').attr('src', 'images/298/black.png');
			}
		});
    
    $(".onl-dc").click(function(){
      $(".ss-onlrad").hide();
      $(".ss-onl-btn").show();
    });
    $(".onl-tt").click(function(){
      $(".ss-onl-btn").hide();
      $(".ss-onlrad").show();
    });
    var Newslide = new Swiper('.ss-new', {
      // spaceBetween: 2,
      slidesPerView: 4,
      freeMode: true,
      watchSlidesVisibility: true,
      watchSlidesProgress: true,
    });
    var TraiN = new Swiper('.ss-train', {
      spaceBetween: 4,
      slidesPerView: 1,
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
      thumbs: {
        swiper: galleryThumbs
      }
    });
    $(document).on('click', '[toscroll]', function (e) {
      e.preventDefault();
      var link = $(this).attr('toscroll');
      if ($(link).length > 0) {
        var posi = $(link).offset().top - 50;
        $('body,html').animate({ scrollTop: posi }, 1000);
      }
    });
    $(".diachi").click(function(){
      $(".googlemap").show();
    });
    // $(".ss-new").responsiveSlides
    // {
    //   var Newslide = new Swiper('.ss-new', {
    //     // spaceBetween: 2,
    //     slidesPerView: 3,
    //     freeMode: true,
    //     watchSlidesVisibility: true,
    //     watchSlidesProgress: true,
    //   });
    // }
    
})(jQuery);